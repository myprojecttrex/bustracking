export const DISTRICT_COORDS = {
  Chennai: { lat: 13.0827, lng: 80.2707 },
  Madurai: { lat: 9.9252, lng: 78.1198 },
  Dindigul: { lat: 10.3673, lng: 77.9803 },
  Coimbatore: { lat: 11.0168, lng: 76.9558 },
  Tirunelveli: { lat: 8.7139, lng: 77.7567 },
  Thoothukudi: { lat: 8.7642, lng: 78.1348 },
  Salem: { lat: 11.6643, lng: 78.1460 },
  Trichy: { lat: 10.7905, lng: 78.7047 },
  Erode: { lat: 11.3410, lng: 77.7172 },
  Vellore: { lat: 12.9165, lng: 79.1325 },
};
